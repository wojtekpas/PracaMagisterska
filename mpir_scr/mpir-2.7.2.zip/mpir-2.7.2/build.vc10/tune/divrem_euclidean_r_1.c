#define TUNE_PROGRAM_BUILD 1
#include "..\..\mpn\generic\divrem_euclidean_r_1.c"
