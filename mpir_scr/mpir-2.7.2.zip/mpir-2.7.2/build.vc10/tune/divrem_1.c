#define TUNE_PROGRAM_BUILD 1
#define __gmpn_divrem_1  mpn_divrem_1_tune
#include "..\..\mpn\generic\divrem_1.c"
