#! /bin/sh
${srcdir}/out_test.sh xdf_test modules/objfmts/xdf/tests "xdf objfmt" "-f xdf" ".xdf"
exit $?
