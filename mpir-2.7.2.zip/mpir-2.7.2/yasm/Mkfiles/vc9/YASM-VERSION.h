#define PACKAGE_STRING "yasm 1.2.0"
#define PACKAGE_VERSION "1.2.0"
